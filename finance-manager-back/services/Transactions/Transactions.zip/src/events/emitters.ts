import { EventEmitter } from 'events';

export const eventEmitter = new EventEmitter();